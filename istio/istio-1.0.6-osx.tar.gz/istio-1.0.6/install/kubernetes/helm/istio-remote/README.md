# Istio Remote

This chart is for preparing a remote cluster to use the Istio components in a primary control plane cluster.

Please follow the installation instructions from [istio.io](https://preliminary.istio.io/docs/setup/kubernetes/multicluster-install/).
